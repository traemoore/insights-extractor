class PageProcessingError(Exception):
    pass

class DocumentProcessingError(Exception):
    pass