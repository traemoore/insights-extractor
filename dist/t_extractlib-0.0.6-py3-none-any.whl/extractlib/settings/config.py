std_out_logging = True
supported_file_types = []
invalid_content_regexs = []
stop_words = []
keywords = {}
keyword_synonyms = { }
word_min_length = 3